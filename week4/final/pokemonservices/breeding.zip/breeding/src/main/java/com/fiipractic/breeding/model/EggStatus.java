package com.fiipractic.breeding.model;

public enum EggStatus {
    PENDING,
    HATCHED
}
