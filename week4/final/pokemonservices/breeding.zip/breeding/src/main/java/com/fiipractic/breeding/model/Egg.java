package com.fiipractic.breeding.model;

import java.time.LocalDateTime;

public class Egg {

    private Integer id;

    private Integer pokemon1;

    private Integer pokemon2;

    private LocalDateTime hatchTime;

    private EggStatus status;
}
